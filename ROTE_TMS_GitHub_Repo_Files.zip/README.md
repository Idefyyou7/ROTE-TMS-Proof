# ROTE-TMS-Proof

Simulated EEG and Python code demonstrating the ROTE hypothesis: that Transcranial Magnetic Stimulation (TMS) restores harmonic phase coherence in φ-indexed bands (e.g., 13 Hz).

## 📄 Contents

- `simulated_tms_eeg.csv` – 30-channel synthetic EEG segment (2 seconds total)
- `tms_event_markers.csv` – TMS pulse at time 0.0 s
- `plv_analysis.py` – Python script to compute Phase Locking Value (PLV)
- `plv_matrix.png` – Output image showing coherence restoration at 13 Hz

## 🧠 Method Summary

Data simulates EEG coherence collapse pre-TMS and restoration post-TMS, time-locked to real pulse markers from OpenNeuro.

## 🧪 How to Run

```bash
pip install numpy pandas scipy matplotlib
python plv_analysis.py
```

## 🧬 License

MIT License. Use freely with attribution.

## 🔗 Contact

Jody Brady, Neo  
Resonant Field Institute  
[jbrady@resonantfieldinstitute.com](mailto:jbrady@resonantfieldinstitute.com)
