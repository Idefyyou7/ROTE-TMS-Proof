import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt, hilbert

# Load EEG data
df = pd.read_csv("simulated_tms_eeg.csv")
data = df.drop(columns=["Time (s)"]).to_numpy()
fs = 1000

# Bandpass filter for 13 Hz
def bandpass_filter(data, lowcut=12, highcut=14, fs=1000, order=3):
    b, a = butter(order, [lowcut / (fs / 2), highcut / (fs / 2)], btype='band')
    return filtfilt(b, a, data, axis=0)

filtered = bandpass_filter(data)

# Compute PLV
n_channels = filtered.shape[1]
analytic_signal = hilbert(filtered, axis=0)
phases = np.angle(analytic_signal)
plv_matrix = np.zeros((n_channels, n_channels))

for i in range(n_channels):
    for j in range(n_channels):
        phase_diff = phases[:, i] - phases[:, j]
        plv_matrix[i, j] = np.abs(np.mean(np.exp(1j * phase_diff)))

# Plot PLV matrix
plt.figure(figsize=(8, 6))
plt.imshow(plv_matrix, cmap='viridis', vmin=0, vmax=1)
plt.colorbar(label="PLV")
plt.title("PLV Matrix at 13 Hz (ROTE Simulation)")
plt.xlabel("Channel")
plt.ylabel("Channel")
plt.tight_layout()
plt.savefig("plv_matrix.png")
plt.show()
